package com.bibleverse.challenge;

import android.app.Activity;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

import java.util.*;

public class MainActivity extends Activity {
    int bg = Color.rgb(11,16,32), card = Color.rgb(25,36,59);
    int gold = Color.rgb(245,199,107), white = Color.WHITE;
    LinearLayout root, content;
    TextView streakView;
    ArrayList<Question> pool = new ArrayList<>(), round = new ArrayList<>();
    int index=0, score=0, correct=0, streak=0, seconds=15;
    CountDownTimer timer;
    boolean answered=false;

    static class Question {
        String prompt, reference, explanation;
        String[] options; int answer;
        Question(String p, String[] o, int a, String r, String e) {
            prompt=p; options=o; answer=a; reference=r; explanation=e;
        }
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        seedQuestions();
        showHome();
    }

    void seedQuestions() {
        pool.add(new Question("Who built the ark?", new String[]{"Moses","Noah","Abraham","David"},1,"Genesis 6:14","God instructed Noah to build an ark."));
        pool.add(new Question("Who defeated Goliath?", new String[]{"Saul","Jonathan","David","Solomon"},2,"1 Samuel 17:50","David defeated Goliath with a sling and a stone."));
        pool.add(new Question("Where was Jesus born?", new String[]{"Nazareth","Jerusalem","Bethlehem","Jericho"},2,"Matthew 2:1","Jesus was born in Bethlehem."));
        pool.add(new Question("Who was swallowed by a great fish?", new String[]{"Jonah","Elijah","Peter","Isaiah"},0,"Jonah 1:17","God appointed a great fish to swallow Jonah."));
        pool.add(new Question("How many days did God create before resting?", new String[]{"Three","Five","Six","Seven"},2,"Genesis 1–2","God created in six days and rested on the seventh."));
        pool.add(new Question("Who was the mother of Samuel?", new String[]{"Ruth","Hannah","Esther","Deborah"},1,"1 Samuel 1:20","Hannah prayed for a child and gave birth to Samuel."));
        pool.add(new Question("What was Jesus' first sign in John's Gospel?", new String[]{"Healing a blind man","Walking on water","Turning water into wine","Feeding five thousand"},2,"John 2:1–11","Jesus turned water into wine at Cana."));
        pool.add(new Question("Who betrayed Jesus?", new String[]{"Peter","Judas Iscariot","Thomas","Andrew"},1,"Matthew 26:14–16","Judas Iscariot agreed to betray Jesus."));
        pool.add(new Question("Who received the Ten Commandments?", new String[]{"Aaron","Joshua","Moses","Abraham"},2,"Exodus 20","God gave the commandments to Moses."));
        pool.add(new Question("What was Peter's occupation?", new String[]{"Carpenter","Tax collector","Fisherman","Soldier"},2,"Matthew 4:18","Peter was a fisherman when Jesus called him."));
        pool.add(new Question("Who interpreted Pharaoh's dreams?", new String[]{"Joseph","Daniel","Moses","Isaac"},0,"Genesis 41","Joseph interpreted Pharaoh's dreams."));
        pool.add(new Question("Which disciple walked on water toward Jesus?", new String[]{"John","Peter","James","Matthew"},1,"Matthew 14:29","Peter stepped out of the boat toward Jesus."));
        pool.add(new Question("Who was known for great strength?", new String[]{"Samson","Gideon","Samuel","Caleb"},0,"Judges 16","Samson was known for extraordinary strength."));
        pool.add(new Question("What is the last book of the Bible?", new String[]{"Jude","Acts","Revelation","Malachi"},2,"Revelation","Revelation is the Bible's final book."));
        pool.add(new Question("Who climbed a sycamore tree to see Jesus?", new String[]{"Nicodemus","Zacchaeus","Bartimaeus","Lazarus"},1,"Luke 19:1–4","Zacchaeus climbed a tree because he was short."));
        pool.add(new Question("Who was the first king of Israel?", new String[]{"David","Solomon","Saul","Hezekiah"},2,"1 Samuel 10","Saul was Israel's first king."));
        pool.add(new Question("How many apostles did Jesus choose?", new String[]{"Seven","Ten","Twelve","Fourteen"},2,"Luke 6:13","Jesus chose twelve apostles."));
        pool.add(new Question("Who was thrown into the lions' den?", new String[]{"Daniel","Jeremiah","Ezekiel","Elisha"},0,"Daniel 6","God protected Daniel in the lions' den."));
    }

    void base(String title) {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22),dp(18),dp(22),dp(20)); root.setBackgroundColor(bg);
        setContentView(root);
        TextView brand = text("✝  BIBLEVERSE CHALLENGE",16,gold,true);
        brand.setGravity(Gravity.CENTER); root.addView(brand, matchWrap());
        TextView heading = text(title,29,white,true);
        heading.setGravity(Gravity.CENTER); heading.setPadding(0,dp(28),0,dp(10));
        root.addView(heading, matchWrap());
        ScrollView scroll = new ScrollView(this);
        content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(2),dp(8),dp(2),dp(8));
        scroll.addView(content); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
    }

    void showHome() {
        base("Know the Word.\nBeat the Clock.");
        TextView desc=text("Five questions. Fifteen seconds each. Grow your Bible knowledge and challenge your friends.",16,0xFFB7C2D8,false);
        desc.setGravity(Gravity.CENTER); desc.setLineSpacing(dp(5),1); content.addView(desc,matchWrap());
        int best=getPreferences(0).getInt("best",0), days=getPreferences(0).getInt("streak",0);
        LinearLayout stats=new LinearLayout(this); stats.setOrientation(LinearLayout.HORIZONTAL);
        stats.addView(statBox("BEST",best+" pts")); stats.addView(statBox("DAILY STREAK","🔥 "+days));
        content.addView(stats,new LinearLayout.LayoutParams(-1,dp(95)));
        TextView note=text("Today's Bible Challenge",20,white,true); note.setPadding(0,dp(25),0,dp(8)); content.addView(note);
        content.addView(text("Answer carefully, learn from each explanation, and see your score at the end.",15,0xFFB7C2D8,false));
        Button start=button("START CHALLENGE  →"); content.addView(start,buttonParams()); start.setOnClickListener(v->startGame());
        TextView foot=text("Free to play • No account required",13,0xFF8996AE,false); foot.setGravity(Gravity.CENTER); foot.setPadding(0,dp(20),0,0); content.addView(foot);
    }

    View statBox(String label,String value) {
        LinearLayout box=new LinearLayout(this); box.setGravity(Gravity.CENTER); box.setOrientation(LinearLayout.VERTICAL);
        box.setBackground(roundBg(card,16)); TextView a=text(label,12,0xFFB7C2D8,true), b=text(value,20,gold,true);
        box.addView(a); box.addView(b); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-1,1); p.setMargins(dp(4),dp(20),dp(4),0); box.setLayoutParams(p); return box;
    }

    void startGame() {
        if(timer!=null) timer.cancel();
        Collections.shuffle(pool); round=new ArrayList<>(pool.subList(0,5));
        index=score=correct=streak=0; showQuestion();
    }

    void showQuestion() {
        answered=false; seconds=15;
        base("Question "+(index+1)+" of 5");
        TextView meta=text("⏱  "+seconds+" seconds                         SCORE  "+score,14,gold,true);
        content.addView(meta,matchWrap());
        TextView q=text(round.get(index).prompt,24,white,true); q.setPadding(0,dp(24),0,dp(20)); content.addView(q);
        Question item=round.get(index);
        for(int i=0;i<item.options.length;i++) {
            final int choice=i;
            Button opt=button((char)('A'+i)+"     "+item.options[i]);
            opt.setGravity(Gravity.CENTER_VERTICAL);
            opt.setTextColor(Color.WHITE);
            opt.setTextSize(17);
            opt.setBackground(roundBg(0xFF202D47,14));
            LinearLayout.LayoutParams p=buttonParams(); p.setMargins(0,dp(5),0,dp(5)); content.addView(opt,p);
            opt.setOnClickListener(v->answer(choice));
        }
        TextView reminder=text("Choose the correct answer before the timer runs out.",13,0xFF9EABC2,false);
        reminder.setPadding(0,dp(16),0,0); content.addView(reminder);
        timer=new CountDownTimer(15000,1000) {
            public void onTick(long ms) { seconds=(int)(ms/1000); meta.setText("⏱  "+seconds+" seconds                         SCORE  "+score); }
            public void onFinish(){ if(!answered) answer(-1); }
        }.start();
    }

    void answer(int choice) {
        if(answered)return; answered=true; if(timer!=null)timer.cancel();
        Question q=round.get(index);
        if(choice==q.answer){ correct++; streak++; score+=100+seconds*10; }
        else streak=0;
        base(choice==q.answer?"Correct! ✓":"Keep learning!");
        TextView result=text(choice==q.answer?"+"+(100+seconds*10)+" POINTS":"Good effort — here's the answer",19,choice==q.answer?0xFF72E6B5:gold,true);
        content.addView(result);
        TextView explanation=text(q.explanation+"\n\nReference: "+q.reference,17,white,false);
        explanation.setPadding(0,dp(18),0,dp(20)); content.addView(explanation);
        TextView progress=text("Score: "+score+"     Correct: "+correct+"/5",15,0xFFB7C2D8,true); content.addView(progress);
        Button next=button(index==4?"VIEW MY RESULTS  →":"NEXT QUESTION  →"); content.addView(next,buttonParams());
        next.setOnClickListener(v->{index++; if(index>=5)showResult(); else showQuestion();});
    }

    void showResult() {
        int best=getPreferences(0).getInt("best",0);
        if(score>best){best=score;getPreferences(0).edit().putInt("best",best).apply();}
        base(correct==5?"Bible Champion! 🏆":"Challenge Complete!");
        TextView points=text(score+" / 500",46,gold,true); points.setGravity(Gravity.CENTER); content.addView(points);
        TextView summary=text(correct+" out of 5 correct\n"+(correct==5?"Perfect score! You know your Scripture.":"Keep playing and growing in the Word."),18,white,false);
        summary.setGravity(Gravity.CENTER); summary.setPadding(0,dp(15),0,dp(22)); content.addView(summary);
        Button share=button("CHALLENGE A FRIEND  ↗"); content.addView(share,buttonParams());
        share.setOnClickListener(v->share());
        Button again=button("PLAY AGAIN"); again.setBackground(roundBg(0xFF26334D,14)); content.addView(again,buttonParams()); again.setOnClickListener(v->startGame());
        Button home=button("HOME"); home.setBackground(roundBg(0xFF26334D,14)); content.addView(home,buttonParams()); home.setOnClickListener(v->showHome());
    }

    void share() {
        String msg="📖 BibleVerse Challenge\nI scored "+correct+"/5 and "+score+" points! Can you beat me? Download and play BibleVerse Challenge.";
        Intent send=new Intent(Intent.ACTION_SEND); send.setType("text/plain"); send.putExtra(Intent.EXTRA_TEXT,msg);
        startActivity(Intent.createChooser(send,"Challenge a friend"));
    }

    TextView text(String s,int size,int color,boolean bold) {
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return t;
    }
    Button button(String s) {
        Button b=new Button(this); b.setText(s); b.setTextColor(0xFF172033); b.setTextSize(15);
        b.setTypeface(Typeface.DEFAULT,Typeface.BOLD); b.setAllCaps(false); b.setBackground(roundBg(gold,14)); return b;
    }
    GradientDrawable roundBg(int color,int radius) {
        GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    int dp(int n){return (int)(n*getResources().getDisplayMetrics().density);}
    LinearLayout.LayoutParams matchWrap(){return new LinearLayout.LayoutParams(-1,-2);}
    LinearLayout.LayoutParams buttonParams(){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(58));p.setMargins(0,dp(10),0,dp(3));return p;}
}
